public class regskylt {

	public static int plate(int[] P) {
		return -1;
	}

}
