int plate(int P[6]);
