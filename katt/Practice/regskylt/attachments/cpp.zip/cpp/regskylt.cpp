int plate(int P[6]) {
	return -1;
}
