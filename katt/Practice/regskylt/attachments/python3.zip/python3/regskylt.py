def plate(P):
    return -1
