public class kakor {

  public static long cookies(int N, int[] A) {
    return -1;
  }

}
