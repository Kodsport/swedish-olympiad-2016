#include "kakor.h"

long long cookies(int N, int A[]) {
  return -1;
}
