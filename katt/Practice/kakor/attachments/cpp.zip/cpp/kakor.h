long long cookies(int N, int A[]);
