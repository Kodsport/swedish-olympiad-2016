def cookies(N, A):
    return -1
