long long fibonacci(int N, char X[]);
