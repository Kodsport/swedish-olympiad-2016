public class fibonacci {

    public static long fibonacci(int N, char[] X) {
        return 0;
    }

}
