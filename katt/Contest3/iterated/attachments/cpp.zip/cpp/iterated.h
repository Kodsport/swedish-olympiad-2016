void init(int N);
int guess(const int ans[]);
