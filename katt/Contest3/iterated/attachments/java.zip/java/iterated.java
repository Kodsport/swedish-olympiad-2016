class iterated {
	public static void init(int N) {
		boolean[] ar = new boolean[N];
		stub.lib.guess(ar);
		ar[0] = ar[1] = ar[2] = true;
		stub.lib.guess(ar);
	}
}
