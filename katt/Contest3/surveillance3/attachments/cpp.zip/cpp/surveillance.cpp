int surveillance(int B, int W, int S[1000][1000], int T[1000][1000]) {
    return 0;
}
