public class surveillance {

    public static int surveillance(int B, int W, int[][] S, int[][] T) {
        return 0;
    }

}
