def cops(N, M, A, B, T):
    pass

def guess(C):
    return -1
