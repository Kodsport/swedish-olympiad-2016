public class mafia {
    public static void cops(int N, int M, int[] A, int[] B, int[] C) {
		}

    public static long guess(int C) {
      return -1;
    }
}
