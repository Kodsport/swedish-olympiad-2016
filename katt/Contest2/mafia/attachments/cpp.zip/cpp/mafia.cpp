#include "mafia.h"

void cops(int N, int M, int A[], int B[], int T[]) {
}

long long guess(int C) {
}
