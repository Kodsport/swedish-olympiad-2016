public class videoclips {
    public static void videos(int K, int M, int[] S) {
		}

    public static int clip(int I) {
      return -1;
    }
}
