def videos(K, M, S):
    pass

def clip(I):
    return -1
