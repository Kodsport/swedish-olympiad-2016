void videos(int K, int M, int S[]);

int clip(int I);
