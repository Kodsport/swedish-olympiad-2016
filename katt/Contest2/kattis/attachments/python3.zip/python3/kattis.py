def kattis(N, H, X, Y, Z):
    return 1
