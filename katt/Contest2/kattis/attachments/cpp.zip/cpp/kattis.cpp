#include "kattis.h"

int kattis(int N, int H, int X[], int Y[], int Z[]) {
	return 1;
}
