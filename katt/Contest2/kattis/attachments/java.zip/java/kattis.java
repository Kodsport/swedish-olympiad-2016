public class kattis {
	public static int kattis(int N, int H, int[] X, int[] Y, int[] Z) {
		return 1;
	}
}

