public class kingdom {
	public static int division(int N, int P, int[] C, int[] F, int[] T) {
		int[] R = new int[N];
		for (int i = 0; i < N; ++i) R[i] = i;
		grader.lib.parts(R);
		return 1;
	}
}
