int division(int N, int P, int C[], int F[], int T[]);

void parts(int R[]);
