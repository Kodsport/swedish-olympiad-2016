#include "kingdom.h"

int division(int N, int P, int C[], int F[], int T[]) {
	int R[N];
	for (int i = 0; i < N; ++i) {
		R[i] = i;
	}
	parts(R);
	return 1;
}
