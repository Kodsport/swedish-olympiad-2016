import grader

def division(N, P, C, F, T):
  grader.parts([i for i in range(N)])
  return 1
