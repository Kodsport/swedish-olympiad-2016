public class friends {
	public static void init(int N, int L, int[] P) {}
	public static void jump(int A, int B) {}
	public static long score() {
		return 0;
	}
}
