#include "friends.h"

void init(int N, int L, int P[]) {}

void jump(int A, int B) {}

long long score() {
	return 0;
}
