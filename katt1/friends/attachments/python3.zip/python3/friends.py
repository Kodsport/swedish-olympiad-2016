
def init(N, L, P):
	pass

def jump(A, B):
	pass

def score():
	return 0
