int tshirt(int N, int L[], int H[], int T[]);
