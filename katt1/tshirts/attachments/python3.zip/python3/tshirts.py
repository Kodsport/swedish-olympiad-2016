def tshirt(N, L, H, T):
    return 0
