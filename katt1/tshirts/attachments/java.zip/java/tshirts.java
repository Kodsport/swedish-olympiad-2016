public class tshirts {

    public static int tshirt(int N, int[] L, int[] H, int[] T) {
        return 0;
    }

}
