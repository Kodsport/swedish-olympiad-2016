#!/usr/bin/env python2
import grader

def magic_score(N, K, L, R):
    for i in range(N):
        grader.trick(0)
    return 0
