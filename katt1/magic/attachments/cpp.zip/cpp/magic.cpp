#include "magic.h"

int magic_score(int N, int K, int L[], int R[]) {
	for (int i = 0; i < N; i++)
		trick(0);
	return 0;
}
