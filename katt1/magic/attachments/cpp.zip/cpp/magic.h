int magic_score(int N, int K, int L[], int R[]);
void trick(int rabbits);
